<?php
echo "Q3 <br><br>";
$number = 8;
    if ($number % 2 == 0) {
        echo "$number is an Even Number";
        }    
    else {
        echo "$number is an Odd Number";
         }
?>