<?php
echo "Q2 <br><br>";
    $value = 1000;
    echo "15% Vat off $value is: ". $value*0.15;

    ?>