<?php
    echo "Q1 <br><br>";
    $length = 10;
    $widh = 5;
    echo "Area: ".$length*$widh;
    echo " <br> perimeter: " .(2*($length+$widh));

?>