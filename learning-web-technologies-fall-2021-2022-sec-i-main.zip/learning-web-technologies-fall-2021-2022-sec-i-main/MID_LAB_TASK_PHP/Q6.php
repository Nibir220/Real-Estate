<?php
    echo "Q6 <br><br>";
    $name = array(1,2,3,4,5,6);

        if (in_array( 5, $name)) {
            echo "Item found in array";
        } else {
            echo "Item not found";
                }
?>