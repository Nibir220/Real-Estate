<?php
 echo "Q5 <br><br>";
 for ($i = 10; $i <= 99; $i += 2) {
     if($i != $i+1){
         echo $i+1 . " ";
     } 
 }
?>