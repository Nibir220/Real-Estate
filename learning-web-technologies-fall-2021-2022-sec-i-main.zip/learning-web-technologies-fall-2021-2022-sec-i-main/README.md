# learning-web-technologies-fall-2021-2022-sec-i
1st class - getting started with git hub