<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
  width: 400px;
  height: 50px;
}
</style>
</head>
<body>

    <table border-style solid>
        <tr>
        <td> <a href="public home.php" > Dashboard </a> </td>
             <td rowspan="7"> Logged inUser </td>
        </tr>
        <tr>
            <td> <a href="public home.php" > View Profile </a> </td>
        </tr>
        <tr>
            <td> <a href="editProfile.html" > Edit Profile </a></td>
        </tr>
        <tr>
            <td> <a href="profilePic.html" > Change Profile Picture </a></td>
        </tr>
        <tr>
            <td> <a href="chnagePass.html" > Change Password </a></td>
        </tr>
        <tr>
            <td> <a href="logout.php" > Logout </a></td>
            
        </tr>
    </table>
    
</body>
</html>