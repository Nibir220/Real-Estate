<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
  width: 400px;
  height: 50px
}
</style>
</head>
<body>

    <table border-style solid>
        <tr>
            <td rowspan="5"> Public User </td>
        </tr>
        <tr>
            <td> <a href="public home.php" > Public Home </a> </td>
        </tr>
        <tr>
            <td> <a href="registration.php" > Registration </a></td>
        </tr>
        <tr>
            <td> <a href="login.php" > Login </a></td>
        </tr>
        <tr>
            <td> <a href="forgotPass.html" > Forgot Password </a></td>
        </tr>
    </table>
    
</body>
</html>