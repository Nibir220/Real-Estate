<html>
<head>
	<title>Create New User Page</title>
	<style>
	.form-center {
		display:flex;
		justify-content: center;
	}
	</style>
</head>
<body>
	
<div class="form-center">
	<form method="post" action="signupCheck.php" >
		<fieldset style="width:40%">
			<legend>REGISTRATION</legend>
			<table>
				<tr>
					<td>ID:</td>
					<td><input type="text" name="idd" value=""></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" name="password" value=""></td>
				</tr>
				<tr>
					<td>Confirm Password:</td>
					<td><input type="password" name="conpassword" value=""></td>
				</tr>
				<tr>
					<td>Name:</td>
					<td><input type="text" name="name" value=""></td>
				</tr>

				<tr>
                    <td>User Type</td>
                    <td> <hr>
                        <input type="radio" name="user"> User
                        <input type="radio" name="user"> Admin
						<hr>
                    </td>
                </tr>
				<tr>
					<td><input type="submit" name="submit" value="Signup"></td>
					<td><a href="login.html">SignIn </a></td>
				</tr>
			</table>
		</fieldset>
	</form>
</div>
	<center>
		<a href="home.php">Back </a> |
		<a href="logout.php">logout </a>
	</center>
</body>
</html>